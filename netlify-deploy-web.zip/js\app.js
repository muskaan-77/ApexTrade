// ApexTrade - Comprehensive Financial Platform Engine
// State
const state = {
  currentUser: null,
  allUsers: [],
  currentRole: 'TRADER', // 'TRADER' or 'ADMIN'
  activeTraderTab: 'trading',
  activeAdminTab: 'users',
  stocks: {},
  selectedSymbol: 'AAPL',
  orderSide: 'BUY',
  portfolio: null,
  systemSettings: null,
  securitySettings: null,
  notifications: [],
  alerts: [],
  charts: {
    stock: null,
    portfolio: null,
    adminTurnover: null,
    adminOrderType: null,
  },
  previousPrices: {},
  pollTimer: null
};

// Initialization
document.addEventListener('DOMContentLoaded', async () => {
  if (window.lucide) lucide.createIcons();
  await loadInitialData();
  startLivePolling();
});

async function loadInitialData() {
  try {
    await fetchUsers();
    await fetchSystemSettings();
    await fetchStocks();
    await fetchSecuritySettings();
    await refreshUserData();
    setupCharts();
  } catch (err) {
    console.error('Initialization error:', err);
    showToast('Failed to connect to backend server. Make sure Java server is running.', 'error');
  }
}

// -----------------------------------------------------------------------------
// Live Polling & Feed Updates
// -----------------------------------------------------------------------------
function startLivePolling() {
  if (state.pollTimer) clearInterval(state.pollTimer);
  state.pollTimer = setInterval(async () => {
    try {
      await fetchStocks(false); // silent update
      if (state.currentRole === 'TRADER') {
        await fetchPortfolio(false);
        await fetchNotifications(false);
        if (state.activeTraderTab === 'alerts') await fetchAlerts();
      } else {
        if (state.activeAdminTab === 'monitoring') await fetchMonitoringData();
        if (state.activeAdminTab === 'system') await fetchSystemSettings();
      }
    } catch (e) {
      console.warn('Poll error:', e);
    }
  }, 2500);
}

// -----------------------------------------------------------------------------
// API Calls & Data Loaders
// -----------------------------------------------------------------------------
async function fetchUsers() {
  const res = await fetch('/api/users');
  const users = await res.json();
  state.allUsers = users;

  // Populate user selector in header
  const selector = document.getElementById('user-selector');
  selector.innerHTML = '';
  users.forEach(u => {
    const opt = document.createElement('option');
    opt.value = u.id;
    opt.textContent = `${u.name} (${u.role})`;
    selector.appendChild(opt);
  });

  // Default to Alex Morgan (trader) if first load
  if (!state.currentUser) {
    const defaultTrader = users.find(u => u.role === 'TRADER') || users[0];
    setCurrentUser(defaultTrader);
  }
}

function setCurrentUser(user) {
  state.currentUser = user;
  document.getElementById('user-selector').value = user.id;
  document.getElementById('current-user-name').textContent = user.name;
  document.getElementById('current-user-role').textContent = user.role;
  document.getElementById('current-user-role').className = user.role === 'ADMIN' ? 'text-[10px] text-blue-400 font-medium' : 'text-[10px] text-emerald-400 font-medium';

  // Initials
  const parts = user.name.split(' ');
  const initials = parts.length > 1 ? (parts[0][0] + parts[1][0]).toUpperCase() : parts[0].substring(0, 2).toUpperCase();
  document.getElementById('user-avatar-initials').textContent = initials;

  // Update header cash
  updateHeaderCash();

  // Switch role view if needed
  switchView(user.role);
}

function onUserSelectionChanged(userId) {
  const user = state.allUsers.find(u => u.id === userId);
  if (user) {
    setCurrentUser(user);
    refreshUserData();
    showToast(`Switched active profile to ${user.name} (${user.role})`, 'info');
  }
}

function updateHeaderCash() {
  if (!state.currentUser) return;
  const cashElem = document.getElementById('header-cash-balance');
  const cash = state.currentUser.cashBalance || 0;
  cashElem.textContent = `$${cash.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const orderCash = document.getElementById('order-available-cash');
  if (orderCash) orderCash.textContent = `$${cash.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

async function refreshUserData() {
  if (!state.currentUser) return;
  if (state.currentRole === 'TRADER') {
    await fetchPortfolio();
    await fetchTrades();
    await fetchAlerts();
    await fetchNotifications();
    await fetchNews('ALL');
  } else {
    await fetchAdminUsers();
    await fetchSecuritySettings();
    await fetchMonitoringData();
  }
}

async function fetchStocks(renderAll = true) {
  const res = await fetch('/api/stocks');
  const stockList = await res.json();

  stockList.forEach(s => {
    state.stocks[s.symbol] = s;
  });

  renderTickerMarquee(stockList);
  renderWatchlist(stockList);

  if (renderAll || !state.charts.stock) {
    updateActiveStockDisplay();
  } else {
    updateStockChartLivePoint();
  }

  // Update alert symbol dropdown if empty
  const alertSymbolSel = document.getElementById('alert-symbol');
  if (alertSymbolSel && alertSymbolSel.options.length === 0) {
    stockList.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.symbol;
      opt.textContent = `${s.symbol} - ${s.name}`;
      alertSymbolSel.appendChild(opt);
    });
  }
}

async function fetchPortfolio(render = true) {
  if (!state.currentUser) return;
  const res = await fetch(`/api/portfolio?userId=${encodeURIComponent(state.currentUser.id)}`);
  const data = await res.json();
  state.portfolio = data;

  // Sync user cash
  if (data.cashBalance !== undefined) {
    state.currentUser.cashBalance = data.cashBalance;
    updateHeaderCash();
  }

  if (render) renderPortfolioOverview(data);
}

async function fetchTrades() {
  if (!state.currentUser) return;
  const res = await fetch(`/api/trades?userId=${encodeURIComponent(state.currentUser.id)}`);
  const trades = await res.json();
  renderTradeHistory(trades);
}

async function fetchAlerts() {
  if (!state.currentUser) return;
  const res = await fetch(`/api/alerts?userId=${encodeURIComponent(state.currentUser.id)}`);
  const alerts = await res.json();
  state.alerts = alerts;
  renderAlerts(alerts);
}

async function fetchNotifications(render = true) {
  if (!state.currentUser) return;
  const res = await fetch(`/api/notifications?userId=${encodeURIComponent(state.currentUser.id)}`);
  const notifs = await res.json();
  state.notifications = notifs;
  if (render) renderNotifications(notifs);
}

async function fetchNews(category = 'ALL') {
  const res = await fetch(`/api/news?category=${encodeURIComponent(category)}`);
  const news = await res.json();
  renderNews(news);
}

async function fetchSecuritySettings() {
  const res = await fetch('/api/security');
  const sec = await res.json();
  state.securitySettings = sec;
  renderSecuritySettings(sec);
}

async function fetchSystemSettings() {
  const res = await fetch('/api/system');
  const sys = await res.json();
  state.systemSettings = sys;
  renderSystemSettings(sys);
}

async function fetchAdminUsers() {
  const res = await fetch('/api/users');
  const users = await res.json();
  state.allUsers = users;
  renderAdminUsersTable(users);
}

async function fetchMonitoringData() {
  const [resMetrics, resTrades] = await Promise.all([
    fetch('/api/analytics'),
    fetch('/api/trades')
  ]);
  const metrics = await resMetrics.json();
  const trades = await resTrades.json();
  renderMonitoring(metrics, trades);
}

// -----------------------------------------------------------------------------
// View & Tab Switching
// -----------------------------------------------------------------------------
function switchView(role) {
  state.currentRole = role;

  const traderBtn = document.getElementById('view-trader-btn');
  const adminBtn = document.getElementById('view-admin-btn');
  const traderTabs = document.getElementById('trader-tabs');
  const adminTabs = document.getElementById('admin-tabs');
  const balancePill = document.getElementById('header-balance-pill');

  // Hide all panels
  document.querySelectorAll('[id^="panel-"]').forEach(p => p.classList.add('hidden'));

  if (role === 'ADMIN') {
    adminBtn.className = 'px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-2 bg-blue-600 text-white shadow-sm';
    traderBtn.className = 'px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-2 text-slate-400 hover:text-white';
    traderTabs.classList.add('hidden');
    adminTabs.classList.remove('hidden');
    balancePill.classList.add('hidden');
    setAdminTab(state.activeAdminTab);
  } else {
    traderBtn.className = 'px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-2 bg-blue-600 text-white shadow-sm';
    adminBtn.className = 'px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-2 text-slate-400 hover:text-white';
    adminTabs.classList.add('hidden');
    traderTabs.classList.remove('hidden');
    balancePill.classList.remove('hidden');
    setTraderTab(state.activeTraderTab);
  }

  if (window.lucide) lucide.createIcons();
}

function setTraderTab(tabKey) {
  state.activeTraderTab = tabKey;
  // Update tab buttons
  document.querySelectorAll('#trader-tabs .nav-tab').forEach(b => b.classList.remove('active'));
  const activeBtn = document.getElementById(`tab-trader-${tabKey}`);
  if (activeBtn) activeBtn.classList.add('active');

  // Show panel
  document.querySelectorAll('[id^="panel-trader-"]').forEach(p => p.classList.add('hidden'));
  const panel = document.getElementById(`panel-trader-${tabKey}`);
  if (panel) panel.classList.remove('hidden');

  // Refresh tab data
  if (tabKey === 'trading') {
    setTimeout(() => { if (state.charts.stock) state.charts.stock.resize(); }, 50);
  } else if (tabKey === 'portfolio') {
    fetchPortfolio();
  } else if (tabKey === 'market-updates') {
    fetchNews('ALL');
  } else if (tabKey === 'trade-history') {
    fetchTrades();
  } else if (tabKey === 'alerts') {
    fetchAlerts();
  }

  if (window.lucide) lucide.createIcons();
}

function setAdminTab(tabKey) {
  state.activeAdminTab = tabKey;
  // Update tab buttons
  document.querySelectorAll('#admin-tabs .nav-tab').forEach(b => b.classList.remove('active'));
  const activeBtn = document.getElementById(`tab-admin-${tabKey}`);
  if (activeBtn) activeBtn.classList.add('active');

  // Show panel
  document.querySelectorAll('[id^="panel-admin-"]').forEach(p => p.classList.add('hidden'));
  const panel = document.getElementById(`panel-admin-${tabKey}`);
  if (panel) panel.classList.remove('hidden');

  // Refresh tab data
  if (tabKey === 'users') {
    fetchAdminUsers();
  } else if (tabKey === 'security') {
    fetchSecuritySettings();
  } else if (tabKey === 'system') {
    fetchSystemSettings();
  } else if (tabKey === 'monitoring') {
    fetchMonitoringData();
  } else if (tabKey === 'reports') {
    generateReport();
  }

  if (window.lucide) lucide.createIcons();
}

// -----------------------------------------------------------------------------
// Rendering: Ticker Marquee & Watchlist
// -----------------------------------------------------------------------------
function renderTickerMarquee(stocks) {
  const container = document.getElementById('ticker-container');
  if (!container) return;

  // Duplicate list for infinite loop
  const displayStocks = [...stocks, ...stocks];
  container.innerHTML = displayStocks.map(s => {
    const isUp = s.change >= 0;
    const sign = isUp ? '+' : '';
    const colorClass = isUp ? 'text-up' : 'text-down';
    const icon = isUp ? '▲' : '▼';
    return `
      <div class="ticker-item" onclick="selectStock('${s.symbol}')">
        <span class="font-bold text-white font-mono">${s.symbol}</span>
        <span class="font-mono text-slate-300">$${s.price.toFixed(2)}</span>
        <span class="font-mono ${colorClass} text-[11px] font-semibold">${icon} ${sign}${s.changePercent.toFixed(2)}%</span>
      </div>
    `;
  }).join('');
}

function renderWatchlist(stocks) {
  const container = document.getElementById('watchlist-container');
  if (!container) return;

  const query = (document.getElementById('watchlist-search')?.value || '').toLowerCase();
  const filtered = stocks.filter(s => s.symbol.toLowerCase().includes(query) || s.name.toLowerCase().includes(query));

  container.innerHTML = filtered.map(s => {
    const isSelected = s.symbol === state.selectedSymbol;
    const isUp = s.change >= 0;
    const sign = isUp ? '+' : '';
    const badgeClass = isUp ? 'badge-up' : 'badge-down';
    const selectedClass = isSelected ? 'border-blue-500/80 bg-blue-950/20 shadow-md' : 'border-[#27354f] bg-[#0f1523] hover:border-slate-600';

    // Flash animation on price change
    const oldPrice = state.previousPrices[s.symbol];
    let flashClass = '';
    if (oldPrice !== undefined && oldPrice !== s.price) {
      flashClass = s.price > oldPrice ? 'flash-up' : 'flash-down';
    }
    state.previousPrices[s.symbol] = s.price;

    return `
      <div onclick="selectStock('${s.symbol}')" class="p-2.5 rounded-lg border ${selectedClass} ${flashClass} cursor-pointer transition flex items-center justify-between">
        <div>
          <div class="flex items-center gap-2">
            <span class="font-bold text-white font-mono text-xs">${s.symbol}</span>
            <span class="text-[11px] text-slate-400 truncate max-w-[110px]">${s.name}</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono mt-0.5">Vol: ${(s.volume / 1000000).toFixed(1)}M</div>
        </div>
        <div class="text-right">
          <div class="font-bold font-mono text-white text-xs">$${s.price.toFixed(2)}</div>
          <span class="text-[10px] font-bold px-1.5 py-0.5 rounded font-mono ${badgeClass} inline-block mt-0.5">${sign}${s.changePercent.toFixed(2)}%</span>
        </div>
      </div>
    `;
  }).join('');
}

function filterWatchlist(query) {
  renderWatchlist(Object.values(state.stocks));
}

function selectStock(symbol) {
  if (!state.stocks[symbol]) return;
  state.selectedSymbol = symbol;
  updateActiveStockDisplay();
  if (state.activeTraderTab !== 'trading') {
    setTraderTab('trading');
  }
}

function updateActiveStockDisplay() {
  const stock = state.stocks[state.selectedSymbol];
  if (!stock) return;

  document.getElementById('chart-symbol').textContent = stock.symbol;
  document.getElementById('chart-company-name').textContent = stock.name;
  document.getElementById('chart-sector').textContent = stock.sector;
  document.getElementById('chart-price').textContent = `$${stock.price.toFixed(2)}`;

  const isUp = stock.change >= 0;
  const sign = isUp ? '+' : '';
  const changeElem = document.getElementById('chart-change');
  changeElem.textContent = `${sign}${stock.change.toFixed(2)} (${sign}${stock.changePercent.toFixed(2)}%)`;
  changeElem.className = isUp ? 'text-xs font-semibold px-2 py-0.5 rounded badge-up font-mono' : 'text-xs font-semibold px-2 py-0.5 rounded badge-down font-mono';

  document.getElementById('chart-high').textContent = `$${stock.dayHigh.toFixed(2)}`;
  document.getElementById('chart-low').textContent = `$${stock.dayLow.toFixed(2)}`;
  document.getElementById('chart-vol').textContent = `${(stock.volume / 1000000).toFixed(1)}M`;
  document.getElementById('chart-mktcap').textContent = stock.marketCap;

  calculateOrderEstimates();
  renderStockChart(stock);
}

function updateStockChartLivePoint() {
  const stock = state.stocks[state.selectedSymbol];
  if (!stock || !state.charts.stock) return;

  // Update text
  document.getElementById('chart-price').textContent = `$${stock.price.toFixed(2)}`;
  const isUp = stock.change >= 0;
  const sign = isUp ? '+' : '';
  const changeElem = document.getElementById('chart-change');
  changeElem.textContent = `${sign}${stock.change.toFixed(2)} (${sign}${stock.changePercent.toFixed(2)}%)`;
  changeElem.className = isUp ? 'text-xs font-semibold px-2 py-0.5 rounded badge-up font-mono' : 'text-xs font-semibold px-2 py-0.5 rounded badge-down font-mono';

  // Update chart data point
  const chart = state.charts.stock;
  if (stock.priceHistory && stock.priceHistory.length > 0) {
    chart.data.labels = stock.priceHistory.map((_, i) => `${i * 5}m`);
    chart.data.datasets[0].data = stock.priceHistory;
    chart.update('none'); // silent update without full re-render
  }
}

// -----------------------------------------------------------------------------
// Interactive Charts Setup (Chart.js)
// -----------------------------------------------------------------------------
function setupCharts() {
  const stock = state.stocks[state.selectedSymbol];
  if (stock) renderStockChart(stock);
}

function renderStockChart(stock) {
  const ctx = document.getElementById('stockChart');
  if (!ctx) return;

  if (state.charts.stock) {
    state.charts.stock.destroy();
  }

  const isUp = stock.change >= 0;
  const lineColor = isUp ? '#10b981' : '#ef4444';
  const fillColor = isUp ? 'rgba(16, 185, 129, 0.08)' : 'rgba(239, 68, 68, 0.08)';

  const history = stock.priceHistory || [stock.price];
  const labels = history.map((_, i) => `${i * 5}m`);

  state.charts.stock = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: `${stock.symbol} Price`,
        data: history,
        borderColor: lineColor,
        backgroundColor: fillColor,
        fill: true,
        borderWidth: 2.5,
        tension: 0.25,
        pointRadius: 0,
        pointHoverRadius: 5,
        pointHoverBackgroundColor: lineColor,
        pointHoverBorderColor: '#ffffff',
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          mode: 'index',
          intersect: false,
          backgroundColor: '#121824',
          borderColor: '#27354f',
          borderWidth: 1,
          titleColor: '#94a3b8',
          bodyColor: '#ffffff',
          callbacks: {
            label: (ctx) => ` Price: $${Number(ctx.parsed.y).toFixed(2)}`
          }
        }
      },
      scales: {
        x: {
          display: true,
          grid: { color: 'rgba(255, 255, 255, 0.03)' },
          ticks: { color: '#64748b', maxTicksLimit: 8, font: { family: 'monospace', size: 10 } }
        },
        y: {
          display: true,
          position: 'right',
          grid: { color: 'rgba(255, 255, 255, 0.04)' },
          ticks: {
            color: '#64748b',
            font: { family: 'monospace', size: 10 },
            callback: (v) => `$${Number(v).toFixed(2)}`
          }
        }
      }
    }
  });
}

function renderPortfolioChart(portfolio) {
  const ctx = document.getElementById('portfolioChart');
  if (!ctx) return;

  if (state.charts.portfolio) {
    state.charts.portfolio.destroy();
  }

  const holdings = portfolio.holdings || [];
  const labels = ['Cash Reserve', ...holdings.map(h => h.symbol)];
  const data = [portfolio.cashBalance || 0, ...holdings.map(h => h.totalValue)];
  const backgroundColors = [
    '#10b981', // green for cash
    '#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#06b6d4', '#6366f1', '#14b8a6'
  ];

  state.charts.portfolio = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: backgroundColors.slice(0, data.length),
        borderColor: '#141c2c',
        borderWidth: 2,
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#94a3b8',
            font: { family: 'monospace', size: 10 },
            boxWidth: 10,
            padding: 8
          }
        },
        tooltip: {
          backgroundColor: '#121824',
          borderColor: '#27354f',
          borderWidth: 1,
          callbacks: {
            label: (ctx) => ` ${ctx.label}: $${Number(ctx.raw).toLocaleString('en-US', { minimumFractionDigits: 2 })}`
          }
        }
      },
      cutout: '65%'
    }
  });
}

// -----------------------------------------------------------------------------
// Trader Feature 1: Stock Trading Execution Engine
// -----------------------------------------------------------------------------
function setOrderTab(side) {
  state.orderSide = side;
  const buyBtn = document.getElementById('order-tab-buy');
  const sellBtn = document.getElementById('order-tab-sell');
  const submitBtn = document.getElementById('order-submit-btn');
  const submitLabel = document.getElementById('order-submit-label');
  const netLabel = document.getElementById('est-net-label');

  if (side === 'BUY') {
    buyBtn.className = 'px-5 py-1 rounded-md text-xs font-bold transition-all bg-emerald-600 text-white shadow';
    sellBtn.className = 'px-5 py-1 rounded-md text-xs font-bold transition-all text-slate-400 hover:text-white';
    submitBtn.className = 'px-6 py-2.5 rounded-lg text-sm font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20 flex items-center gap-2 transition';
    submitLabel.textContent = `Execute BUY Order`;
    netLabel.textContent = 'TOTAL REQUIRED';
  } else {
    sellBtn.className = 'px-5 py-1 rounded-md text-xs font-bold transition-all bg-red-600 text-white shadow';
    buyBtn.className = 'px-5 py-1 rounded-md text-xs font-bold transition-all text-slate-400 hover:text-white';
    submitBtn.className = 'px-6 py-2.5 rounded-lg text-sm font-bold bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-600/20 flex items-center gap-2 transition';
    submitLabel.textContent = `Execute SELL Order`;
    netLabel.textContent = 'NET PROCEEDS';
  }

  calculateOrderEstimates();
}

function onOrderTypeChange(type) {
  const limitGroup = document.getElementById('limit-price-group');
  const limitInput = document.getElementById('order-limit-price');
  const stock = state.stocks[state.selectedSymbol];

  if (type === 'LIMIT') {
    limitGroup.classList.remove('opacity-50');
    limitInput.disabled = false;
    if (stock && !limitInput.value) {
      limitInput.value = stock.price.toFixed(2);
    }
  } else {
    limitGroup.classList.add('opacity-50');
    limitInput.disabled = true;
    limitInput.value = '';
  }
  calculateOrderEstimates();
}

function adjustQty(amount) {
  const qtyInput = document.getElementById('order-qty');
  const current = parseInt(qtyInput.value) || 0;
  qtyInput.value = Math.max(1, current + amount);
  calculateOrderEstimates();
}

function calculateOrderEstimates() {
  const stock = state.stocks[state.selectedSymbol];
  if (!stock) return;

  const qty = parseInt(document.getElementById('order-qty').value) || 0;
  const orderType = document.getElementById('order-type').value;
  let unitPrice = stock.price;

  if (orderType === 'LIMIT') {
    const limitVal = parseFloat(document.getElementById('order-limit-price').value);
    if (!isNaN(limitVal) && limitVal > 0) {
      unitPrice = limitVal;
    }
  }

  const feeRate = (state.systemSettings?.tradingFeePercent || 0.15) / 100.0;
  const gross = qty * unitPrice;
  const fee = gross * feeRate;
  const totalCost = state.orderSide === 'BUY' ? (gross + fee) : Math.max(0, gross - fee);

  document.getElementById('est-unit-price').textContent = `$${unitPrice.toFixed(2)}`;
  document.getElementById('est-gross-amount').textContent = `$${gross.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  document.getElementById('est-fee').textContent = `$${fee.toFixed(2)}`;
  document.getElementById('est-total-cost').textContent = `$${totalCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

async function handleOrderSubmit(e) {
  e.preventDefault();

  if (!state.currentUser) {
    showToast('Please select a user profile to trade.', 'error');
    return;
  }

  const stock = state.stocks[state.selectedSymbol];
  if (!stock) return;

  const qty = parseInt(document.getElementById('order-qty').value);
  const orderType = document.getElementById('order-type').value;
  let limitPrice = null;

  if (orderType === 'LIMIT') {
    limitPrice = parseFloat(document.getElementById('order-limit-price').value);
    if (isNaN(limitPrice) || limitPrice <= 0) {
      showToast('Please specify a valid limit price.', 'error');
      return;
    }
  }

  const payload = {
    userId: state.currentUser.id,
    symbol: stock.symbol,
    quantity: qty,
    type: state.orderSide,
    orderType: orderType,
    limitPrice: limitPrice
  };

  try {
    const res = await fetch('/api/trade', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();

    if (result.success) {
      showConfirmationBanner(result.message);
      showToast(result.message, 'success');

      // Refresh portfolio, balance, trades
      await fetchPortfolio();
      await fetchTrades();
      await fetchNotifications();
    } else {
      showToast(result.message || 'Trade execution failed.', 'error');
    }
  } catch (err) {
    console.error('Order submit error:', err);
    showToast('Trade submission failed due to connection error.', 'error');
  }
}

// -----------------------------------------------------------------------------
// Trader Feature 2: Portfolio Tracking
// -----------------------------------------------------------------------------
function renderPortfolioOverview(port) {
  if (!port) return;

  document.getElementById('port-total-value').textContent = `$${port.totalPortfolioValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  document.getElementById('port-cash-balance').textContent = `$${port.cashBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  document.getElementById('port-stocks-value').textContent = `$${port.stockHoldingsValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const pnlElem = document.getElementById('port-pnl');
  const pnlPctElem = document.getElementById('port-pnl-pct');
  const isUp = port.totalUnrealizedPnL >= 0;
  const sign = isUp ? '+' : '';

  pnlElem.textContent = `${sign}$${port.totalUnrealizedPnL.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  pnlElem.className = isUp ? 'text-2xl font-bold font-mono text-emerald-400' : 'text-2xl font-bold font-mono text-red-400';

  pnlPctElem.textContent = `${sign}${port.totalReturnPercent.toFixed(2)}% overall return`;
  pnlPctElem.className = isUp ? 'text-xs font-semibold font-mono text-emerald-500' : 'text-xs font-semibold font-mono text-red-500';

  // Holdings Table
  const tbody = document.getElementById('holdings-table-body');
  const badge = document.getElementById('holdings-count-badge');
  badge.textContent = `${port.holdings.length} Positions`;

  if (!port.holdings || port.holdings.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-slate-500 text-xs">No stock holdings currently in portfolio. Execute a BUY order to start investing.</td></tr>`;
  } else {
    tbody.innerHTML = port.holdings.map(h => {
      const posUp = h.unrealizedPnL >= 0;
      const posSign = posUp ? '+' : '';
      const pnlColor = posUp ? 'text-emerald-400' : 'text-red-400';
      const badgeStyle = posUp ? 'badge-up' : 'badge-down';

      return `
        <tr>
          <td>
            <div class="flex items-center gap-2">
              <span class="font-bold text-white font-mono text-xs">${h.symbol}</span>
              <span class="text-slate-400 text-xs truncate max-w-[140px]">${h.companyName}</span>
            </div>
          </td>
          <td class="font-mono text-slate-200 text-xs font-bold">${h.quantity}</td>
          <td class="font-mono text-slate-400 text-xs">$${h.avgBuyPrice.toFixed(2)}</td>
          <td class="font-mono text-white text-xs font-semibold">$${h.currentPrice.toFixed(2)}</td>
          <td class="font-mono text-slate-200 text-xs font-bold">$${h.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
          <td>
            <div class="${pnlColor} font-mono font-bold text-xs">${posSign}$${h.unrealizedPnL.toFixed(2)}</div>
            <span class="text-[10px] px-1 py-0.2 rounded font-mono ${badgeStyle}">${posSign}${h.returnPercent.toFixed(2)}%</span>
          </td>
          <td class="text-right">
            <button onclick="quickTradeFromPortfolio('${h.symbol}')" class="px-2.5 py-1 rounded bg-[#182234] hover:bg-blue-600 text-slate-200 hover:text-white border border-[#27354f] text-[11px] font-semibold transition">
              Trade
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  // Allocation Donut Chart
  renderPortfolioChart(port);
}

function quickTradeFromPortfolio(symbol) {
  selectStock(symbol);
  setTraderTab('trading');
}

// -----------------------------------------------------------------------------
// Trader Feature 3: Market Updates
// -----------------------------------------------------------------------------
function filterNews(cat) {
  document.querySelectorAll('.news-filter-btn').forEach(btn => {
    if (btn.getAttribute('data-cat') === cat) {
      btn.className = 'news-filter-btn px-3 py-1 rounded-lg text-xs font-semibold bg-blue-600 text-white';
    } else {
      btn.className = 'news-filter-btn px-3 py-1 rounded-lg text-xs font-semibold bg-[#0f1523] text-slate-400 hover:text-white';
    }
  });
  fetchNews(cat);
}

function renderNews(newsList) {
  const container = document.getElementById('news-container');
  if (!container) return;

  if (!newsList || newsList.length === 0) {
    container.innerHTML = `<div class="col-span-2 text-center py-10 text-slate-500 text-xs">No market updates matching filter.</div>`;
    return;
  }

  container.innerHTML = newsList.map(n => {
    let sentimentBadge = 'bg-slate-800 text-slate-300';
    if (n.sentiment === 'BULLISH') sentimentBadge = 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
    else if (n.sentiment === 'BEARISH') sentimentBadge = 'bg-red-500/10 text-red-400 border border-red-500/20';
    else sentimentBadge = 'bg-amber-500/10 text-amber-400 border border-amber-500/20';

    return `
      <div class="card p-4 space-y-2 hover:border-blue-500/40 transition">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 uppercase font-mono">${n.category}</span>
            <span class="text-[11px] text-slate-400">${n.source}</span>
          </div>
          <span class="text-[10px] text-slate-500 font-mono">${n.timeAgo}</span>
        </div>
        <h4 class="font-bold text-sm text-white leading-snug hover:text-blue-400 cursor-pointer" onclick="selectStock('${n.relatedSymbol}')">${n.title}</h4>
        <p class="text-xs text-slate-400">${n.summary}</p>
        <div class="flex items-center justify-between pt-2 border-t border-[#27354f]/50">
          <span class="text-[10px] font-bold px-2 py-0.5 rounded font-mono ${sentimentBadge}">● ${n.sentiment}</span>
          <button onclick="selectStock('${n.relatedSymbol}')" class="text-xs text-blue-400 hover:text-blue-300 font-mono font-semibold flex items-center gap-1">
            Trade ${n.relatedSymbol} &rarr;
          </button>
        </div>
      </div>
    `;
  }).join('');
}

// -----------------------------------------------------------------------------
// Trader Feature 4: Trade History
// -----------------------------------------------------------------------------
let allTraderHistory = [];

function renderTradeHistory(trades) {
  allTraderHistory = trades || [];
  filterTradeHistory(document.getElementById('trades-filter')?.value || '');
}

function filterTradeHistory(query) {
  const tbody = document.getElementById('trade-history-table-body');
  if (!tbody) return;

  const q = (query || '').toLowerCase();
  const filtered = allTraderHistory.filter(t =>
    t.symbol.toLowerCase().includes(q) ||
    t.id.toLowerCase().includes(q) ||
    t.type.toLowerCase().includes(q)
  );

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" class="text-center py-8 text-slate-500 text-xs">No trade history found.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(t => {
    const isBuy = t.type === 'BUY';
    const sideBadge = isBuy ? 'badge-up' : 'badge-down';

    return `
      <tr>
        <td class="font-mono text-xs text-slate-400 font-bold">${t.id}</td>
        <td class="font-mono text-xs text-slate-400">${t.timestamp}</td>
        <td class="font-mono text-xs font-bold text-white">${t.symbol}</td>
        <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${sideBadge}">${t.type}</span></td>
        <td class="font-mono text-xs text-slate-400">${t.orderType}</td>
        <td class="font-mono text-xs text-slate-200 font-bold">${t.quantity}</td>
        <td class="font-mono text-xs text-slate-300">$${t.price.toFixed(2)}</td>
        <td class="font-mono text-xs text-white font-bold">$${t.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
        <td class="font-mono text-xs text-slate-400">$${t.fee.toFixed(2)}</td>
        <td><span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">${t.status}</span></td>
      </tr>
    `;
  }).join('');
}

function exportTraderHistoryCsv() {
  if (!state.currentUser) return;
  window.open(`/api/reports/export?type=FINANCIAL_AUDIT`, '_blank');
}

// -----------------------------------------------------------------------------
// Trader Feature 5: Alerts & Notifications
// -----------------------------------------------------------------------------
async function handleCreateAlert(e) {
  e.preventDefault();
  if (!state.currentUser) return;

  const symbol = document.getElementById('alert-symbol').value;
  const condition = document.getElementById('alert-condition').value;
  const targetPrice = parseFloat(document.getElementById('alert-target-price').value);
  const note = document.getElementById('alert-note').value;

  const payload = {
    userId: state.currentUser.id,
    symbol: symbol,
    condition: condition,
    targetPrice: targetPrice,
    note: note
  };

  try {
    const res = await fetch('/api/alerts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      showConfirmationBanner(result.message);
      showToast(result.message, 'success');
      document.getElementById('alert-target-price').value = '';
      document.getElementById('alert-note').value = '';
      await fetchAlerts();
    } else {
      showToast(result.message, 'error');
    }
  } catch (err) {
    showToast('Failed to create price alert.', 'error');
  }
}

async function deleteAlert(alertId) {
  try {
    const res = await fetch(`/api/alerts?id=${encodeURIComponent(alertId)}`, { method: 'DELETE' });
    const result = await res.json();
    if (result.success) {
      showToast(result.message, 'info');
      await fetchAlerts();
    }
  } catch (err) {
    showToast('Failed to delete alert.', 'error');
  }
}

function renderAlerts(alerts) {
  const tbody = document.getElementById('alerts-table-body');
  const badge = document.getElementById('alerts-count-badge');
  badge.textContent = `${alerts.length} Monitored`;

  if (!alerts || alerts.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-slate-500 text-xs">No active price alerts set. Use the form on the left to set thresholds.</td></tr>`;
    return;
  }

  tbody.innerHTML = alerts.map(a => {
    const isTriggered = a.status === 'TRIGGERED';
    const statusBadge = isTriggered
      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
      : 'bg-blue-500/10 text-blue-400 border border-blue-500/30';

    return `
      <tr>
        <td class="font-mono text-xs font-bold text-white">${a.symbol}</td>
        <td class="font-mono text-xs text-slate-300">${a.condition === 'ABOVE' ? '&ge; Above' : '&le; Below'}</td>
        <td class="font-mono text-xs font-bold text-amber-400">$${a.targetPrice.toFixed(2)}</td>
        <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${statusBadge}">${a.status}</span></td>
        <td class="font-mono text-xs text-slate-400">${a.createdAt}</td>
        <td class="text-right">
          <button onclick="deleteAlert('${a.id}')" class="text-slate-400 hover:text-red-400 p-1 text-xs">
            <i data-lucide="trash-2" class="w-4 h-4"></i>
          </button>
        </td>
      </tr>
    `;
  }).join('');

  if (window.lucide) lucide.createIcons();
}

function renderNotifications(notifs) {
  const badge = document.getElementById('notif-badge');
  const list = document.getElementById('notif-list');

  const unreadCount = notifs.filter(n => !n.read).length;
  if (unreadCount > 0) {
    badge.textContent = unreadCount;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }

  if (notifs.length === 0) {
    list.innerHTML = `<div class="p-4 text-center text-xs text-slate-500">No new notifications.</div>`;
    return;
  }

  list.innerHTML = notifs.map(n => {
    let icon = 'info';
    let iconColor = 'text-blue-400';
    if (n.type === 'TRADE') { icon = 'check-circle'; iconColor = 'text-emerald-400'; }
    else if (n.type === 'ALERT') { icon = 'bell-ring'; iconColor = 'text-amber-400'; }
    else if (n.type === 'SECURITY') { icon = 'shield'; iconColor = 'text-indigo-400'; }

    return `
      <div class="p-3 hover:bg-[#182234] transition flex items-start gap-2.5 ${n.read ? 'opacity-70' : 'bg-blue-950/20'}">
        <i data-lucide="${icon}" class="w-4 h-4 ${iconColor} mt-0.5 shrink-0"></i>
        <div class="flex-1">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-white">${n.title}</span>
            <span class="text-[10px] text-slate-500 font-mono">${n.timestamp.split(' ')[1] || ''}</span>
          </div>
          <p class="text-xs text-slate-300 mt-0.5">${n.message}</p>
        </div>
      </div>
    `;
  }).join('');

  if (window.lucide) lucide.createIcons();
}

function toggleNotificationDropdown() {
  const dd = document.getElementById('notif-dropdown');
  dd.classList.toggle('hidden');
}

async function clearAllNotifications() {
  if (!state.currentUser) return;
  await fetch(`/api/notifications/clear?userId=${encodeURIComponent(state.currentUser.id)}`, { method: 'POST' });
  await fetchNotifications();
}

// -----------------------------------------------------------------------------
// Admin Feature 1: User Management
// -----------------------------------------------------------------------------
function renderAdminUsersTable(users) {
  const tbody = document.getElementById('users-table-body');
  if (!tbody) return;

  tbody.innerHTML = users.map(u => {
    const isMaster = u.id === 'usr_admin';
    const isAdmin = u.role === 'ADMIN';
    const roleBadge = isAdmin
      ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
      : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
    const statusBadge = u.status === 'ACTIVE'
      ? 'bg-emerald-500/10 text-emerald-400'
      : 'bg-red-500/10 text-red-400';

    return `
      <tr>
        <td class="font-mono text-xs text-slate-400 font-semibold">${u.id}</td>
        <td class="font-bold text-white text-xs">${u.name}</td>
        <td class="font-mono text-xs text-slate-400">${u.email}</td>
        <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${roleBadge}">${u.role}</span></td>
        <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${statusBadge}">${u.status}</span></td>
        <td class="font-mono text-xs text-emerald-400 font-bold">$${u.cashBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
        <td class="font-mono text-xs text-slate-500">${u.createdAt}</td>
        <td class="text-right">
          <div class="flex items-center justify-end gap-2">
            <button onclick="openEditUserModal('${u.id}')" class="px-2 py-1 rounded bg-[#182234] hover:bg-[#1f2c42] text-xs text-blue-400 border border-[#27354f] transition">
              Edit
            </button>
            ${!isMaster ? `
              <button onclick="deleteUser('${u.id}', '${u.name}')" class="px-2 py-1 rounded bg-red-950/40 hover:bg-red-900/60 text-xs text-red-400 border border-red-500/20 transition">
                Delete
              </button>
            ` : '<span class="text-[10px] text-slate-500 italic">Protected</span>'}
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function openAddUserModal() {
  document.getElementById('modal-add-user').classList.add('active');
}

function openEditUserModal(userId) {
  const user = state.allUsers.find(u => u.id === userId);
  if (!user) return;

  document.getElementById('edit-user-id').value = user.id;
  document.getElementById('edit-user-name').value = user.name;
  document.getElementById('edit-user-email').value = user.email;
  document.getElementById('edit-user-role').value = user.role;
  document.getElementById('edit-user-status').value = user.status;
  document.getElementById('edit-user-cash').value = user.cashBalance;

  document.getElementById('modal-edit-user').classList.add('active');
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('active');
}

async function handleAddUserSubmit(e) {
  e.preventDefault();
  const payload = {
    name: document.getElementById('add-user-name').value,
    email: document.getElementById('add-user-email').value,
    role: document.getElementById('add-user-role').value,
    initialCash: parseFloat(document.getElementById('add-user-cash').value)
  };

  try {
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      closeModal('modal-add-user');
      showConfirmationBanner(result.message);
      showToast(result.message, 'success');
      await fetchUsers();
      await fetchAdminUsers();
    } else {
      showToast(result.message, 'error');
    }
  } catch (err) {
    showToast('Failed to add user.', 'error');
  }
}

async function handleEditUserSubmit(e) {
  e.preventDefault();
  const payload = {
    id: document.getElementById('edit-user-id').value,
    name: document.getElementById('edit-user-name').value,
    email: document.getElementById('edit-user-email').value,
    role: document.getElementById('edit-user-role').value,
    status: document.getElementById('edit-user-status').value,
    cashBalance: parseFloat(document.getElementById('edit-user-cash').value)
  };

  try {
    const res = await fetch('/api/users', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      closeModal('modal-edit-user');
      showConfirmationBanner(result.message);
      showToast(result.message, 'success');
      await fetchUsers();
      await fetchAdminUsers();
    } else {
      showToast(result.message, 'error');
    }
  } catch (err) {
    showToast('Failed to update user.', 'error');
  }
}

async function deleteUser(userId, userName) {
  if (!confirm(`Are you sure you want to permanently delete user '${userName}'?`)) return;

  try {
    const res = await fetch(`/api/users?id=${encodeURIComponent(userId)}`, { method: 'DELETE' });
    const result = await res.json();
    if (result.success) {
      showConfirmationBanner(result.message);
      showToast(result.message, 'info');
      await fetchUsers();
      await fetchAdminUsers();
    } else {
      showToast(result.message, 'error');
    }
  } catch (err) {
    showToast('Failed to delete user.', 'error');
  }
}

// -----------------------------------------------------------------------------
// Admin Feature 2: Financial Data Security
// -----------------------------------------------------------------------------
function renderSecuritySettings(sec) {
  if (!sec) return;

  document.getElementById('sec-score').textContent = `${sec.securityScore} / 100`;
  document.getElementById('sec-enc-display').textContent = sec.encryptionStandard;
  document.getElementById('sec-last-scan').textContent = sec.lastSecurityScan;

  document.getElementById('sec-encryption').value = sec.encryptionStandard;
  document.getElementById('sec-timeout').value = sec.sessionTimeoutMinutes;
  document.getElementById('sec-max-failed').value = sec.maxFailedLoginAttempts;
  document.getElementById('sec-mfa').checked = sec.mfaEnforced;
  document.getElementById('sec-audit-log').checked = sec.auditLogging;
  document.getElementById('sec-ip-whitelist').checked = sec.ipWhitelisting;

  // Incidents table
  const tbody = document.getElementById('incidents-table-body');
  if (tbody) {
    tbody.innerHTML = (sec.recentIncidents || []).map(inc => {
      let sevClass = 'bg-blue-500/10 text-blue-400';
      if (inc.severity === 'CRITICAL') sevClass = 'bg-red-500/10 text-red-400 border border-red-500/30';
      else if (inc.severity === 'WARNING') sevClass = 'bg-amber-500/10 text-amber-400 border border-amber-500/30';

      return `
        <tr>
          <td class="font-mono text-xs font-bold text-white">${inc.id}</td>
          <td class="font-mono text-xs text-slate-400">${inc.timestamp}</td>
          <td>
            <div class="text-xs font-bold text-white">${inc.event}</div>
            <div class="text-[11px] text-slate-400">${inc.details}</div>
          </td>
          <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${sevClass}">${inc.severity}</span></td>
          <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-emerald-500/10 text-emerald-400">${inc.status}</span></td>
        </tr>
      `;
    }).join('');
  }
}

async function handleSecuritySettingsSubmit(e) {
  e.preventDefault();

  const payload = {
    encryptionStandard: document.getElementById('sec-encryption').value,
    sessionTimeoutMinutes: parseInt(document.getElementById('sec-timeout').value),
    maxFailedLoginAttempts: parseInt(document.getElementById('sec-max-failed').value),
    mfaEnforced: document.getElementById('sec-mfa').checked,
    auditLogging: document.getElementById('sec-audit-log').checked,
    ipWhitelisting: document.getElementById('sec-ip-whitelist').checked
  };

  try {
    const res = await fetch('/api/security', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      showConfirmationBanner(result.message);
      showToast(result.message, 'success');
      await fetchSecuritySettings();
    }
  } catch (err) {
    showToast('Failed to update security settings.', 'error');
  }
}

async function triggerSecurityScan() {
  try {
    const res = await fetch('/api/security/scan', { method: 'POST' });
    const result = await res.json();
    if (result.success) {
      showConfirmationBanner(result.message);
      showToast(result.message, 'success');
      await fetchSecuritySettings();
    }
  } catch (err) {
    showToast('Failed to execute compliance audit scan.', 'error');
  }
}

async function triggerSimulatedIncident() {
  const events = [
    { title: 'Concurrent Session Anomaly', sev: 'WARNING', details: 'User account logged in from two geographic regions simultaneously.' },
    { title: 'Brute Force Attack Mitigated', sev: 'CRITICAL', details: 'Automated IP jail blocked 45 rapid invalid password attempts.' },
    { title: 'API Key Hash Rotation', sev: 'INFO', details: 'Scheduled cryptographic key rotation completed cleanly.' }
  ];
  const ev = events[Math.floor(Math.random() * events.length)];

  await fetch('/api/security', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ encryptionStandard: 'AES-256-GCM' })
  });
  showToast(`Security event logged: ${ev.title}`, 'info');
  await fetchSecuritySettings();
}

// -----------------------------------------------------------------------------
// Admin Feature 3: System Settings
// -----------------------------------------------------------------------------
function renderSystemSettings(sys) {
  if (!sys) return;

  document.getElementById('sys-platform-name').value = sys.platformName;
  document.getElementById('sys-fee').value = sys.tradingFeePercent;
  document.getElementById('sys-max-order').value = sys.maxDailyOrderLimit;
  document.getElementById('sys-currency').value = sys.defaultCurrency;
  document.getElementById('sys-market-open').checked = sys.marketOpen;
  document.getElementById('sys-maintenance-mode').checked = sys.maintenanceMode;

  // Header status pill
  const dot = document.getElementById('market-status-dot');
  const txt = document.getElementById('market-status-text');
  if (sys.maintenanceMode) {
    dot.className = 'pulse-dot closed';
    txt.textContent = 'MAINTENANCE';
    txt.className = 'text-red-400 font-bold';
  } else if (!sys.marketOpen) {
    dot.className = 'pulse-dot closed';
    txt.textContent = 'MARKET CLOSED';
    txt.className = 'text-amber-400 font-bold';
  } else {
    dot.className = 'pulse-dot';
    txt.textContent = 'MARKET OPEN';
    txt.className = 'text-emerald-400 font-bold';
  }

  // Telemetry metrics
  const status = sys.status || {};
  document.getElementById('metric-uptime').textContent = status.uptime || '--';
  document.getElementById('metric-memory').textContent = `${status.memoryUsedMb || 0} MB / ${status.memoryMaxMb || 1024} MB`;
  document.getElementById('metric-threads').textContent = `${status.activeThreads || 12} Threads`;
  document.getElementById('metric-health').textContent = status.engineHealth || 'OPTIMAL';
}

async function handleSystemSettingsSubmit(e) {
  e.preventDefault();

  const payload = {
    platformName: document.getElementById('sys-platform-name').value,
    tradingFeePercent: parseFloat(document.getElementById('sys-fee').value),
    maxDailyOrderLimit: parseInt(document.getElementById('sys-max-order').value),
    defaultCurrency: document.getElementById('sys-currency').value,
    marketOpen: document.getElementById('sys-market-open').checked,
    maintenanceMode: document.getElementById('sys-maintenance-mode').checked
  };

  try {
    const res = await fetch('/api/system', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      showConfirmationBanner(result.message);
      showToast(result.message, 'success');
      await fetchSystemSettings();
    }
  } catch (err) {
    showToast('Failed to update system settings.', 'error');
  }
}

// -----------------------------------------------------------------------------
// Admin Feature 4: Trade Activity Monitoring
// -----------------------------------------------------------------------------
function renderMonitoring(metrics, trades) {
  document.getElementById('mon-trades-count').textContent = metrics.totalTrades || 0;
  document.getElementById('mon-volume-usd').textContent = `$${(metrics.totalVolumeUsd || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  document.getElementById('mon-fees-usd').textContent = `$${(metrics.totalPlatformFeesUsd || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  document.getElementById('mon-buysell-ratio').textContent = `${metrics.buyOrdersCount || 0} BUY / ${metrics.sellOrdersCount || 0} SELL`;

  // Render Turnover Bar Chart
  const turnoverCtx = document.getElementById('adminTurnoverChart');
  if (turnoverCtx) {
    if (state.charts.adminTurnover) state.charts.adminTurnover.destroy();

    const turnoverMap = metrics.turnoverByStock || {};
    const symbols = Object.keys(turnoverMap);
    const turnovers = Object.values(turnoverMap);

    state.charts.adminTurnover = new Chart(turnoverCtx, {
      type: 'bar',
      data: {
        labels: symbols,
        datasets: [{
          label: 'Turnover ($)',
          data: turnovers,
          backgroundColor: '#3b82f6',
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: 'rgba(255, 255, 255, 0.03)' }, ticks: { color: '#94a3b8', font: { family: 'monospace' } } },
          y: { grid: { color: 'rgba(255, 255, 255, 0.03)' }, ticks: { color: '#94a3b8', callback: (v) => `$${Number(v).toLocaleString()}` } }
        }
      }
    });
  }

  // Render Order Type Doughnut Chart
  const orderCtx = document.getElementById('adminOrderTypeChart');
  if (orderCtx) {
    if (state.charts.adminOrderType) state.charts.adminOrderType.destroy();

    state.charts.adminOrderType = new Chart(orderCtx, {
      type: 'pie',
      data: {
        labels: ['Buy Orders', 'Sell Orders'],
        datasets: [{
          data: [metrics.buyOrdersCount || 1, metrics.sellOrdersCount || 0],
          backgroundColor: ['#10b981', '#ef4444'],
          borderColor: '#121824',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { color: '#94a3b8', font: { family: 'monospace', size: 11 } } }
        }
      }
    });
  }

  // Global trades table
  const tbody = document.getElementById('global-trades-table-body');
  if (tbody) {
    tbody.innerHTML = (trades || []).slice(0, 20).map(t => {
      const isBuy = t.type === 'BUY';
      const badgeStyle = isBuy ? 'badge-up' : 'badge-down';
      return `
        <tr>
          <td class="font-mono text-xs text-slate-400 font-bold">${t.id}</td>
          <td class="font-mono text-xs text-slate-400">${t.timestamp}</td>
          <td class="font-bold text-white text-xs">${t.userName}</td>
          <td class="font-mono text-xs font-bold text-white">${t.symbol}</td>
          <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${badgeStyle}">${t.type}</span></td>
          <td class="font-mono text-xs text-slate-400">${t.orderType}</td>
          <td class="font-mono text-xs text-slate-200 font-bold">${t.quantity}</td>
          <td class="font-mono text-xs text-slate-300">$${t.price.toFixed(2)}</td>
          <td class="font-mono text-xs text-white font-bold">$${t.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
          <td class="font-mono text-xs text-slate-400">$${t.fee.toFixed(2)}</td>
        </tr>
      `;
    }).join('');
  }
}

// -----------------------------------------------------------------------------
// Admin Feature 5: Report Generation
// -----------------------------------------------------------------------------
async function generateReport() {
  const select = document.getElementById('report-type-select');
  const type = select.value;

  try {
    const res = await fetch(`/api/reports?type=${encodeURIComponent(type)}`);
    const data = await res.json();
    renderReportOutput(data);
    showToast(`Compiled report: ${data.title}`, 'success');
  } catch (err) {
    showToast('Failed to compile report.', 'error');
  }
}

function renderReportOutput(rep) {
  document.getElementById('report-title').textContent = rep.title;
  document.getElementById('report-timestamp').textContent = `Generated: ${rep.generatedAt} | Exchange: ${rep.platform}`;
  document.getElementById('report-type-badge').textContent = rep.reportType;

  const body = document.getElementById('report-body');

  if (rep.reportType === 'PORTFOLIO_SUMMARY') {
    body.innerHTML = `
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Total Cash Custody</span>
          <span class="text-xl font-bold font-mono text-emerald-400">$${rep.totalCashUnderCustody.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Total Equities Custody</span>
          <span class="text-xl font-bold font-mono text-purple-400">$${rep.totalEquitiesUnderCustody.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Assets Under Management (AUM)</span>
          <span class="text-xl font-bold font-mono text-white">$${rep.totalAssetsUnderManagement.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
        </div>
      </div>
      <div class="overflow-x-auto">
        <table class="data-table">
          <thead>
            <tr>
              <th>User ID</th>
              <th>Trader Name</th>
              <th>Cash Reserves</th>
              <th>Equities Value</th>
              <th>Total Net Worth</th>
              <th>Positions</th>
            </tr>
          </thead>
          <tbody>
            ${(rep.userPortfolios || []).map(u => `
              <tr>
                <td class="font-mono text-xs text-slate-400 font-bold">${u.userId}</td>
                <td class="font-bold text-white text-xs">${u.userName}</td>
                <td class="font-mono text-xs text-emerald-400">$${u.cashBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                <td class="font-mono text-xs text-purple-400">$${u.stockValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                <td class="font-mono text-xs text-white font-bold">$${u.totalNetWorth.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                <td class="font-mono text-xs text-slate-300">${u.holdingsCount}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } else if (rep.reportType === 'SYSTEM_ANALYTICS') {
    body.innerHTML = `
      <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4">
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Total Registered Traders</span>
          <span class="text-xl font-bold font-mono text-white">${rep.totalUsersRegistered}</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Security Score</span>
          <span class="text-xl font-bold font-mono text-emerald-400">${rep.securityScore} / 100</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Active Price Triggers</span>
          <span class="text-xl font-bold font-mono text-amber-400">${rep.activePriceAlerts}</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Exchange Fee</span>
          <span class="text-xl font-bold font-mono text-blue-400">${rep.currentFeePercent}%</span>
        </div>
      </div>
      <div class="p-4 rounded-lg bg-[#141c2c] border border-[#27354f] space-y-2 text-xs font-mono">
        <div class="flex justify-between text-slate-300"><span>Engine Operating State:</span><span class="text-emerald-400 font-bold">${rep.marketStatus}</span></div>
        <div class="flex justify-between text-slate-300"><span>Security Threat Events Logged:</span><span class="text-white">${rep.securityIncidentsLogged} Incidents</span></div>
        <div class="flex justify-between text-slate-300"><span>System Uptime:</span><span class="text-white">${rep.systemStatus?.uptime || '--'}</span></div>
        <div class="flex justify-between text-slate-300"><span>JVM Heap Allocation:</span><span class="text-blue-400">${rep.systemStatus?.memoryUsedMb || 0} MB</span></div>
      </div>
    `;
  } else {
    // FINANCIAL_AUDIT
    body.innerHTML = `
      <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-4">
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Gross Trade Turnover</span>
          <span class="text-xl font-bold font-mono text-emerald-400">$${rep.grossTradeTurnover.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Exchange Fee Commissions</span>
          <span class="text-xl font-bold font-mono text-purple-400">$${rep.totalPlatformRevenueFees.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Total Executed Trades</span>
          <span class="text-xl font-bold font-mono text-white">${rep.totalTradesExecuted}</span>
        </div>
        <div class="p-3 rounded-lg bg-[#141c2c] border border-[#27354f]">
          <span class="text-[11px] text-slate-400 block">Average Order Size</span>
          <span class="text-xl font-bold font-mono text-blue-400">$${rep.averageTradeSize.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
        </div>
      </div>
      <div class="overflow-x-auto">
        <table class="data-table">
          <thead>
            <tr>
              <th>Trade ID</th>
              <th>Date Time</th>
              <th>Trader</th>
              <th>Symbol</th>
              <th>Side</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Turnover</th>
              <th>Fee</th>
            </tr>
          </thead>
          <tbody>
            ${(rep.auditedTrades || []).map(t => `
              <tr>
                <td class="font-mono text-xs text-slate-400 font-bold">${t.id}</td>
                <td class="font-mono text-xs text-slate-400">${t.timestamp}</td>
                <td class="font-bold text-white text-xs">${t.userName}</td>
                <td class="font-mono text-xs font-bold text-white">${t.symbol}</td>
                <td><span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${t.type === 'BUY' ? 'badge-up' : 'badge-down'}">${t.type}</span></td>
                <td class="font-mono text-xs text-slate-200 font-bold">${t.quantity}</td>
                <td class="font-mono text-xs text-slate-300">$${t.price.toFixed(2)}</td>
                <td class="font-mono text-xs text-white font-bold">$${t.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                <td class="font-mono text-xs text-slate-400">$${t.fee.toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }
}

function downloadReportCsv() {
  const type = document.getElementById('report-type-select').value;
  window.open(`/api/reports/export?type=${encodeURIComponent(type)}`, '_blank');
}

// -----------------------------------------------------------------------------
// Toast & Banner Utilities
// -----------------------------------------------------------------------------
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = 'info';
  if (type === 'success') icon = 'check-circle';
  if (type === 'error') icon = 'alert-triangle';
  if (type === 'warning') icon = 'alert-circle';

  toast.innerHTML = `
    <i data-lucide="${icon}" class="w-4 h-4 shrink-0"></i>
    <span class="text-xs font-medium leading-relaxed">${message}</span>
  `;

  container.appendChild(toast);
  if (window.lucide) lucide.createIcons();

  setTimeout(() => {
    toast.style.animation = 'toast-out 0.3s ease-in forwards';
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}

function showConfirmationBanner(message) {
  const banner = document.getElementById('confirmation-banner');
  const text = document.getElementById('confirmation-banner-text');
  if (!banner || !text) return;

  text.textContent = message;
  banner.classList.remove('hidden');

  // Auto hide after 8s
  setTimeout(() => {
    dismissConfirmationBanner();
  }, 8000);
}

function dismissConfirmationBanner() {
  const banner = document.getElementById('confirmation-banner');
  if (banner) banner.classList.add('hidden');
}
