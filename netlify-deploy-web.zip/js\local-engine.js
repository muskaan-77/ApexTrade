/**
 * ApexTrade Universal Engine & Netlify Cloud Adapter
 * Enables the platform to run seamlessly on Netlify (Static Hosting)
 * with full client-side state persistence (localStorage), simulated price ticks,
 * order execution, user management, and report export.
 */

(function () {
  const STORAGE_KEY = 'apextrade_cloud_state_v1';
  let isStandaloneMode = false;

  // Detect Netlify or static environment
  if (
    window.location.hostname.includes('netlify.app') ||
    window.location.hostname.includes('github.io') ||
    window.location.hostname.includes('vercel.app') ||
    window.location.protocol === 'file:'
  ) {
    isStandaloneMode = true;
  }

  // Pre-seeded initial data for Netlify deployment
  function getInitialState() {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 19);
    return {
      users: [
        { id: 'usr_admin', name: 'Eleanor Vance (Chief Admin)', email: 'admin@apex.com', role: 'ADMIN', status: 'ACTIVE', cashBalance: 0.0, createdAt: nowStr },
        { id: 'usr_trader1', name: 'Alex Morgan', email: 'alex.trader@apex.com', role: 'TRADER', status: 'ACTIVE', cashBalance: 48250.0, createdAt: nowStr },
        { id: 'usr_trader2', name: 'Sarah Chen', email: 'sarah.chen@apex.com', role: 'TRADER', status: 'ACTIVE', cashBalance: 25800.5, createdAt: nowStr },
        { id: 'usr_trader3', name: 'David Miller', email: 'david.m@apex.com', role: 'TRADER', status: 'ACTIVE', cashBalance: 14320.0, createdAt: nowStr }
      ],
      stocks: {
        AAPL: { symbol: 'AAPL', name: 'Apple Inc.', price: 182.45, previousClose: 180.20, change: 2.25, changePercent: 1.25, dayHigh: 183.90, dayLow: 179.80, volume: 54200000, marketCap: '$2.82T', sector: 'Technology', priceHistory: [178.5, 179.2, 180.1, 180.8, 181.4, 182.0, 182.45] },
        MSFT: { symbol: 'MSFT', name: 'Microsoft Corp.', price: 415.80, previousClose: 412.50, change: 3.30, changePercent: 0.80, dayHigh: 418.00, dayLow: 411.20, volume: 24100000, marketCap: '$3.09T', sector: 'Technology', priceHistory: [411.0, 412.5, 413.2, 414.0, 414.8, 415.2, 415.80] },
        NVDA: { symbol: 'NVDA', name: 'NVIDIA Corporation', price: 128.65, previousClose: 124.90, change: 3.75, changePercent: 3.00, dayHigh: 130.40, dayLow: 124.50, volume: 89300000, marketCap: '$3.16T', sector: 'Semiconductors', priceHistory: [123.5, 124.8, 126.0, 127.2, 128.1, 128.65] },
        GOOGL: { symbol: 'GOOGL', name: 'Alphabet Inc.', price: 176.30, previousClose: 174.80, change: 1.50, changePercent: 0.86, dayHigh: 177.50, dayLow: 174.10, volume: 21900000, marketCap: '$2.19T', sector: 'Technology', priceHistory: [173.0, 174.2, 175.0, 175.8, 176.30] },
        AMZN: { symbol: 'AMZN', name: 'Amazon.com Inc.', price: 186.75, previousClose: 188.10, change: -1.35, changePercent: -0.72, dayHigh: 189.20, dayLow: 185.60, volume: 36400000, marketCap: '$1.94T', sector: 'Consumer Cyclical', priceHistory: [188.0, 187.5, 186.9, 186.75] },
        TSLA: { symbol: 'TSLA', name: 'Tesla Inc.', price: 246.20, previousClose: 240.50, change: 5.70, changePercent: 2.37, dayHigh: 249.80, dayLow: 239.10, volume: 68900000, marketCap: '$784B', sector: 'Automotive / Clean Energy', priceHistory: [239.0, 241.5, 244.0, 246.20] },
        JPM: { symbol: 'JPM', name: 'JPMorgan Chase & Co.', price: 198.50, previousClose: 197.20, change: 1.30, changePercent: 0.66, dayHigh: 199.40, dayLow: 196.80, volume: 12800000, marketCap: '$568B', sector: 'Financial Services', priceHistory: [196.5, 197.0, 197.8, 198.50] },
        META: { symbol: 'META', name: 'Meta Platforms Inc.', price: 508.90, previousClose: 501.30, change: 7.60, changePercent: 1.52, dayHigh: 512.40, dayLow: 499.80, volume: 18200000, marketCap: '$1.29T', sector: 'Communication', priceHistory: [500.0, 503.2, 506.0, 508.90] }
      },
      portfolios: {
        usr_trader1: [
          { symbol: 'AAPL', companyName: 'Apple Inc.', quantity: 60, avgBuyPrice: 174.50, currentPrice: 182.45, totalValue: 10947.0, unrealizedPnL: 477.0, returnPercent: 4.56 },
          { symbol: 'NVDA', companyName: 'NVIDIA Corporation', quantity: 120, avgBuyPrice: 114.20, currentPrice: 128.65, totalValue: 15438.0, unrealizedPnL: 1734.0, returnPercent: 12.65 },
          { symbol: 'MSFT', companyName: 'Microsoft Corp.', quantity: 25, avgBuyPrice: 398.00, currentPrice: 415.80, totalValue: 10395.0, unrealizedPnL: 445.0, returnPercent: 4.47 },
          { symbol: 'TSLA', companyName: 'Tesla Inc.', quantity: 30, avgBuyPrice: 228.60, currentPrice: 246.20, totalValue: 7386.0, unrealizedPnL: 528.0, returnPercent: 7.70 }
        ],
        usr_trader2: [
          { symbol: 'AMZN', companyName: 'Amazon.com Inc.', quantity: 40, avgBuyPrice: 181.00, currentPrice: 186.75, totalValue: 7470.0, unrealizedPnL: 230.0, returnPercent: 3.18 },
          { symbol: 'META', companyName: 'Meta Platforms Inc.', quantity: 15, avgBuyPrice: 485.00, currentPrice: 508.90, totalValue: 7633.5, unrealizedPnL: 358.5, returnPercent: 4.93 }
        ],
        usr_trader3: [
          { symbol: 'JPM', companyName: 'JPMorgan Chase & Co.', quantity: 45, avgBuyPrice: 192.40, currentPrice: 198.50, totalValue: 8932.5, unrealizedPnL: 274.5, returnPercent: 3.17 }
        ]
      },
      trades: [
        { id: 'TRD-106', userId: 'usr_trader1', userName: 'Alex Morgan', symbol: 'TSLA', type: 'BUY', orderType: 'MARKET', quantity: 30, price: 228.60, totalAmount: 6858.0, fee: 10.29, timestamp: '2026-10-08 11:15:22', status: 'EXECUTED' },
        { id: 'TRD-105', userId: 'usr_trader3', userName: 'David Miller', symbol: 'JPM', type: 'BUY', orderType: 'MARKET', quantity: 45, price: 192.40, totalAmount: 8658.0, fee: 12.99, timestamp: '2026-10-08 09:40:15', status: 'EXECUTED' },
        { id: 'TRD-104', userId: 'usr_trader1', userName: 'Alex Morgan', symbol: 'MSFT', type: 'BUY', orderType: 'MARKET', quantity: 25, price: 398.00, totalAmount: 9950.0, fee: 14.93, timestamp: '2026-10-07 14:45:30', status: 'EXECUTED' },
        { id: 'TRD-103', userId: 'usr_trader2', userName: 'Sarah Chen', symbol: 'AMZN', type: 'BUY', orderType: 'MARKET', quantity: 40, price: 181.00, totalAmount: 7240.0, fee: 10.86, timestamp: '2026-10-07 10:14:05', status: 'EXECUTED' },
        { id: 'TRD-102', userId: 'usr_trader1', userName: 'Alex Morgan', symbol: 'NVDA', type: 'BUY', orderType: 'LIMIT', quantity: 120, price: 114.20, totalAmount: 13704.0, fee: 20.56, timestamp: '2026-10-06 11:20:44', status: 'EXECUTED' },
        { id: 'TRD-101', userId: 'usr_trader1', userName: 'Alex Morgan', symbol: 'AAPL', type: 'BUY', orderType: 'MARKET', quantity: 60, price: 174.50, totalAmount: 10470.0, fee: 15.71, timestamp: '2026-10-06 09:35:12', status: 'EXECUTED' }
      ],
      securitySettings: {
        encryptionStandard: 'AES-256-GCM',
        mfaEnforced: true,
        sessionTimeoutMinutes: 15,
        maxFailedLoginAttempts: 5,
        ipWhitelisting: false,
        auditLogging: true,
        sslTlsVersion: 'TLS 1.3',
        lastSecurityScan: '2026-10-08 14:30 UTC',
        securityScore: 98,
        recentIncidents: [
          { id: 'INC-8841', timestamp: '2026-10-08 12:45:00', event: 'Rate Limit Guard Activated', severity: 'INFO', status: 'RESOLVED', details: 'Spike of unauthenticated requests throttled automatically.' },
          { id: 'INC-8839', timestamp: '2026-10-07 18:22:10', event: 'Privilege Escalation Audit', severity: 'WARNING', status: 'MITIGATED', details: 'Blocked unauthorized test role modification attempt.' },
          { id: 'INC-8820', timestamp: '2026-10-05 08:15:33', event: 'TLS Cipher Negotiation', severity: 'INFO', status: 'RESOLVED', details: 'Transitioned all connections to TLS 1.3.' }
        ]
      },
      systemSettings: {
        platformName: 'ApexTrade Global Exchange',
        tradingFeePercent: 0.15,
        marketOpen: true,
        maintenanceMode: false,
        maxDailyOrderLimit: 500,
        defaultCurrency: 'USD ($)',
        simVolatility: 1.0,
        status: {
          uptime: '04h 18m 32s',
          memoryUsedMb: 68,
          memoryMaxMb: 512,
          activeThreads: 16,
          engineHealth: 'OPTIMAL (Netlify Edge Active)'
        }
      },
      alerts: [
        { id: 'alt_1', userId: 'usr_trader1', symbol: 'NVDA', targetPrice: 135.00, condition: 'ABOVE', status: 'ACTIVE', createdAt: nowStr, note: 'Take profit target' },
        { id: 'alt_2', userId: 'usr_trader1', symbol: 'TSLA', targetPrice: 235.00, condition: 'BELOW', status: 'ACTIVE', createdAt: nowStr, note: 'Stop-loss watch' }
      ],
      notifications: [
        { id: 'notif_1', userId: 'usr_trader1', title: 'Order Executed: BUY 30 TSLA', message: 'Your Market order for 30 shares of TSLA at $228.60 was executed successfully.', type: 'TRADE', timestamp: '2026-10-08 11:15:22', read: false },
        { id: 'notif_2', userId: 'usr_trader1', title: 'Security Alert: MFA Active', message: 'Two-Factor Authentication is currently enforced for your account.', type: 'SECURITY', timestamp: '2026-10-08 09:00:00', read: true }
      ],
      news: [
        { id: 'n1', title: 'Tech Titans Fuel Wall Street Surge Following Cloud Infrastructure Gains', summary: 'Key enterprise tech companies recorded record margins in cloud services, lifting benchmarks.', category: 'TECH', source: 'Bloomberg Terminal', timeAgo: '12m ago', sentiment: 'BULLISH', relatedSymbol: 'MSFT' },
        { id: 'n2', title: 'Semiconductor Architecture Innovation Accelerates AI Datacenter Rollouts', summary: 'Next-generation chip clusters demonstrate a 40% efficiency boost.', category: 'TECH', source: 'Reuters Financial', timeAgo: '34m ago', sentiment: 'BULLISH', relatedSymbol: 'NVDA' },
        { id: 'n3', title: 'Central Bank Officials Signal Stable Interest Rates Through Q4', summary: 'Federal Reserve remarks emphasize balanced growth and stable consumer indices.', category: 'MACRO', source: 'Wall Street Journal', timeAgo: '1h ago', sentiment: 'NEUTRAL', relatedSymbol: 'JPM' },
        { id: 'n4', title: 'Electric Vehicle Delivery Metrics Exceed Autumn Estimates', summary: 'Global delivery milestones for EV flagships rose 8% quarter-over-quarter.', category: 'TECH', source: 'CNBC MarketWatch', timeAgo: '2h ago', sentiment: 'BULLISH', relatedSymbol: 'TSLA' },
        { id: 'n5', title: 'Digital Advertising Revenue Rebounds Strongly in Global Commerce', summary: 'E-commerce ad impressions jumped heading into the holiday preparation quarter.', category: 'FINANCE', source: 'Financial Times', timeAgo: '3h ago', sentiment: 'BULLISH', relatedSymbol: 'AMZN' }
      ]
    };
  }

  function loadState() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage load failed, using default state:', e);
    }
    const fresh = getInitialState();
    saveState(fresh);
    return fresh;
  }

  function saveState(st) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(st));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }

  const localState = loadState();

  // Background in-browser tick simulation for Netlify
  setInterval(() => {
    if (!isStandaloneMode) return;
    if (!localState.systemSettings.marketOpen || localState.systemSettings.maintenanceMode) return;

    Object.values(localState.stocks).forEach(stock => {
      const changePct = (Math.random() - 0.49) * 0.008;
      const newPrice = Math.max(1.0, Math.round((stock.price * (1 + changePct)) * 100) / 100);
      stock.price = newPrice;
      stock.change = Math.round((newPrice - stock.previousClose) * 100) / 100;
      stock.changePercent = Math.round(((newPrice - stock.previousClose) / stock.previousClose * 100) * 100) / 100;
      if (newPrice > stock.dayHigh) stock.dayHigh = newPrice;
      if (newPrice < stock.dayLow) stock.dayLow = newPrice;
      stock.volume += Math.floor(Math.random() * 800) + 100;
      if (!stock.priceHistory) stock.priceHistory = [];
      stock.priceHistory.push(newPrice);
      if (stock.priceHistory.length > 30) stock.priceHistory.shift();

      // Check alerts
      localState.alerts.forEach(a => {
        if (a.status === 'ACTIVE' && a.symbol === stock.symbol) {
          if ((a.condition === 'ABOVE' && stock.price >= a.targetPrice) ||
              (a.condition === 'BELOW' && stock.price <= a.targetPrice)) {
            a.status = 'TRIGGERED';
            const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
            a.triggeredAt = now;
            localState.notifications.unshift({
              id: 'notif_' + Date.now(),
              userId: a.userId,
              title: `Alert Triggered: ${stock.symbol}`,
              message: `Price reached $${stock.price.toFixed(2)} (${a.condition} $${a.targetPrice.toFixed(2)})`,
              type: 'ALERT',
              timestamp: now,
              read: false
            });
          }
        }
      });
    });

    saveState(localState);
  }, 2500);

  // Mock response builder
  function makeResponse(data, status = 200, contentType = 'application/json') {
    const isJson = contentType === 'application/json';
    const bodyStr = isJson ? JSON.stringify(data) : data;
    return new Response(bodyStr, {
      status,
      headers: { 'Content-Type': contentType }
    });
  }

  // Local API Dispatcher
  async function handleLocalApi(url, options = {}) {
    const method = (options.method || 'GET').toUpperCase();
    const urlObj = new URL(url, window.location.origin);
    const path = urlObj.pathname;
    const params = urlObj.searchParams;
    let body = {};
    if (options.body) {
      try { body = JSON.parse(options.body); } catch (_) {}
    }

    // 1. /api/stocks
    if (path === '/api/stocks') {
      return makeResponse(Object.values(localState.stocks));
    }

    // 2. /api/users
    if (path === '/api/users') {
      if (method === 'GET') {
        return makeResponse(localState.users);
      }
      if (method === 'POST') {
        const id = 'usr_' + Date.now();
        const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
        const newUser = {
          id,
          name: body.name || 'New User',
          email: body.email || 'user@apex.com',
          role: body.role || 'TRADER',
          status: 'ACTIVE',
          cashBalance: parseFloat(body.initialCash) || 25000.0,
          createdAt: now
        };
        localState.users.push(newUser);
        saveState(localState);
        return makeResponse({ success: true, message: `Confirmation: User '${newUser.name}' created with role ${newUser.role}.`, user: newUser }, 201);
      }
      if (method === 'PUT') {
        const user = localState.users.find(u => u.id === body.id);
        if (user) {
          if (body.name) user.name = body.name;
          if (body.email) user.email = body.email;
          if (body.role) user.role = body.role;
          if (body.status) user.status = body.status;
          if (body.cashBalance !== undefined) user.cashBalance = parseFloat(body.cashBalance);
          saveState(localState);
          return makeResponse({ success: true, message: `Confirmation: User '${user.name}' updated successfully.`, user });
        }
        return makeResponse({ success: false, message: 'User not found' }, 404);
      }
      if (method === 'DELETE') {
        const id = params.get('id');
        if (id === 'usr_admin') {
          return makeResponse({ success: false, message: 'Cannot delete master administrator account.' }, 400);
        }
        const idx = localState.users.findIndex(u => u.id === id);
        if (idx !== -1) {
          const removed = localState.users.splice(idx, 1)[0];
          delete localState.portfolios[id];
          saveState(localState);
          return makeResponse({ success: true, message: `Confirmation: User '${removed.name}' permanently deleted.` });
        }
        return makeResponse({ success: false, message: 'User not found' }, 404);
      }
    }

    // 3. /api/trade
    if (path === '/api/trade' && method === 'POST') {
      const { userId, symbol, quantity, type, orderType, limitPrice } = body;
      const user = localState.users.find(u => u.id === userId);
      const stock = localState.stocks[symbol];
      if (!user || !stock) return makeResponse({ success: false, message: 'Invalid user or stock' }, 400);

      const execPrice = (orderType === 'LIMIT' && limitPrice) ? limitPrice : stock.price;
      const feeRate = (localState.systemSettings.tradingFeePercent || 0.15) / 100.0;
      const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 19);
      const tradeId = 'TRD-' + Date.now().toString().slice(-6);

      if (!localState.portfolios[userId]) localState.portfolios[userId] = [];
      const userHoldings = localState.portfolios[userId];

      if (type === 'BUY') {
        const gross = quantity * execPrice;
        const fee = gross * feeRate;
        const total = gross + fee;
        if (user.cashBalance < total) {
          return makeResponse({ success: false, message: `Insufficient cash. Required: $${total.toFixed(2)}, Available: $${user.cashBalance.toFixed(2)}` }, 400);
        }
        user.cashBalance = Math.round((user.cashBalance - total) * 100) / 100;
        let item = userHoldings.find(h => h.symbol === symbol);
        if (item) {
          const newQty = item.quantity + quantity;
          const newAvg = (item.quantity * item.avgBuyPrice + gross) / newQty;
          item.quantity = newQty;
          item.avgBuyPrice = Math.round(newAvg * 100) / 100;
        } else {
          userHoldings.push({
            symbol,
            companyName: stock.name,
            quantity,
            avgBuyPrice: execPrice,
            currentPrice: stock.price,
            totalValue: quantity * stock.price,
            unrealizedPnL: 0,
            returnPercent: 0
          });
        }
        const trade = { id: tradeId, userId, userName: user.name, symbol, type: 'BUY', orderType: orderType || 'MARKET', quantity, price: execPrice, totalAmount: gross, fee, timestamp: nowStr, status: 'EXECUTED' };
        localState.trades.unshift(trade);
        saveState(localState);
        return makeResponse({ success: true, message: `Confirmation: Successfully bought ${quantity} shares of ${symbol} at $${execPrice.toFixed(2)}.`, trade });
      } else {
        // SELL
        let item = userHoldings.find(h => h.symbol === symbol);
        if (!item || item.quantity < quantity) {
          return makeResponse({ success: false, message: `Insufficient shares. Held: ${item ? item.quantity : 0}` }, 400);
        }
        const gross = quantity * execPrice;
        const fee = gross * feeRate;
        const netCredit = gross - fee;
        user.cashBalance = Math.round((user.cashBalance + netCredit) * 100) / 100;
        item.quantity -= quantity;
        if (item.quantity <= 0) {
          localState.portfolios[userId] = userHoldings.filter(h => h.symbol !== symbol);
        }
        const trade = { id: tradeId, userId, userName: user.name, symbol, type: 'SELL', orderType: orderType || 'MARKET', quantity, price: execPrice, totalAmount: gross, fee, timestamp: nowStr, status: 'EXECUTED' };
        localState.trades.unshift(trade);
        saveState(localState);
        return makeResponse({ success: true, message: `Confirmation: Successfully sold ${quantity} shares of ${symbol} for $${netCredit.toFixed(2)}.`, trade });
      }
    }

    // 4. /api/portfolio
    if (path === '/api/portfolio') {
      const uid = params.get('userId') || 'usr_trader1';
      const user = localState.users.find(u => u.id === uid) || { cashBalance: 50000 };
      const holdings = localState.portfolios[uid] || [];
      let equitiesVal = 0;
      let costBasis = 0;
      holdings.forEach(h => {
        const s = localState.stocks[h.symbol];
        if (s) h.currentPrice = s.price;
        h.totalValue = Math.round((h.quantity * h.currentPrice) * 100) / 100;
        const itemCost = h.quantity * h.avgBuyPrice;
        h.unrealizedPnL = Math.round((h.totalValue - itemCost) * 100) / 100;
        h.returnPercent = itemCost > 0 ? Math.round(((h.unrealizedPnL / itemCost) * 100) * 100) / 100 : 0;
        equitiesVal += h.totalValue;
        costBasis += itemCost;
      });
      const totalWorth = Math.round((user.cashBalance + equitiesVal) * 100) / 100;
      const totalPnL = Math.round((equitiesVal - costBasis) * 100) / 100;
      const returnPct = costBasis > 0 ? Math.round(((totalPnL / costBasis) * 100) * 100) / 100 : 0;
      return makeResponse({
        userId: uid,
        cashBalance: user.cashBalance,
        stockHoldingsValue: Math.round(equitiesVal * 100) / 100,
        totalPortfolioValue: totalWorth,
        totalUnrealizedPnL: totalPnL,
        totalReturnPercent: returnPct,
        holdings
      });
    }

    // 5. /api/trades
    if (path === '/api/trades') {
      const uid = params.get('userId');
      const list = uid ? localState.trades.filter(t => t.userId === uid) : localState.trades;
      return makeResponse(list);
    }

    // 6. /api/security
    if (path === '/api/security') {
      if (method === 'POST') {
        Object.assign(localState.securitySettings, body);
        saveState(localState);
        return makeResponse({ success: true, message: 'Confirmation: Financial security policies updated successfully.' });
      }
      return makeResponse(localState.securitySettings);
    }

    if (path === '/api/security/scan') {
      localState.securitySettings.lastSecurityScan = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' (Cloud Audit)';
      saveState(localState);
      return makeResponse({ success: true, message: 'Confirmation: Security compliance audit passed with 0 vulnerabilities.' });
    }

    // 7. /api/system
    if (path === '/api/system') {
      if (method === 'POST') {
        Object.assign(localState.systemSettings, body);
        saveState(localState);
        return makeResponse({ success: true, message: 'Confirmation: System configuration updated successfully.' });
      }
      return makeResponse(localState.systemSettings);
    }

    // 8. /api/analytics
    if (path === '/api/analytics') {
      let totalTrades = localState.trades.length;
      let totalVolume = 0;
      let totalFees = 0;
      let buyCount = 0;
      let sellCount = 0;
      let turnoverByStock = {};
      localState.trades.forEach(t => {
        totalVolume += t.totalAmount;
        totalFees += t.fee;
        if (t.type === 'BUY') buyCount++; else sellCount++;
        turnoverByStock[t.symbol] = (turnoverByStock[t.symbol] || 0) + t.totalAmount;
      });
      return makeResponse({
        totalTrades,
        totalVolumeUsd: Math.round(totalVolume * 100) / 100,
        totalPlatformFeesUsd: Math.round(totalFees * 100) / 100,
        buyOrdersCount: buyCount,
        sellOrdersCount: sellCount,
        turnoverByStock,
        systemStatus: localState.systemSettings.status
      });
    }

    // 9. /api/reports
    if (path === '/api/reports') {
      const type = params.get('type') || 'FINANCIAL_AUDIT';
      const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
      if (type === 'PORTFOLIO_SUMMARY') {
        let cashTotal = 0, eqTotal = 0;
        const summaries = localState.users.filter(u => u.role === 'TRADER').map(u => {
          cashTotal += u.cashBalance;
          const hList = localState.portfolios[u.id] || [];
          const eqVal = hList.reduce((acc, h) => acc + (h.quantity * (localState.stocks[h.symbol]?.price || h.currentPrice)), 0);
          eqTotal += eqVal;
          return {
            userId: u.id,
            userName: u.name,
            cashBalance: u.cashBalance,
            stockValue: Math.round(eqVal * 100) / 100,
            totalNetWorth: Math.round((u.cashBalance + eqVal) * 100) / 100,
            holdingsCount: hList.length
          };
        });
        return makeResponse({
          reportType: type,
          title: 'Global Trader Portfolio & Asset Allocation Audit',
          generatedAt: now,
          platform: 'ApexTrade (Netlify Cloud Edition)',
          totalCashUnderCustody: Math.round(cashTotal * 100) / 100,
          totalEquitiesUnderCustody: Math.round(eqTotal * 100) / 100,
          totalAssetsUnderManagement: Math.round((cashTotal + eqTotal) * 100) / 100,
          userPortfolios: summaries
        });
      } else if (type === 'SYSTEM_ANALYTICS') {
        return makeResponse({
          reportType: type,
          title: 'Infrastructure & Security Analytics',
          generatedAt: now,
          platform: 'ApexTrade (Netlify Cloud Edition)',
          totalUsersRegistered: localState.users.length,
          securityScore: localState.securitySettings.securityScore,
          securityIncidentsLogged: localState.securitySettings.recentIncidents.length,
          activePriceAlerts: localState.alerts.length,
          currentFeePercent: localState.systemSettings.tradingFeePercent,
          marketStatus: localState.systemSettings.marketOpen ? 'OPEN' : 'CLOSED',
          systemStatus: localState.systemSettings.status
        });
      } else {
        let totalTurnover = 0, totalFees = 0, buys = 0, sells = 0;
        localState.trades.forEach(t => {
          totalTurnover += t.totalAmount;
          totalFees += t.fee;
          if (t.type === 'BUY') buys++; else sells++;
        });
        return makeResponse({
          reportType: type,
          title: 'Comprehensive Financial & Turnover Audit',
          generatedAt: now,
          platform: 'ApexTrade (Netlify Cloud Edition)',
          totalTradesExecuted: localState.trades.length,
          grossTradeTurnover: Math.round(totalTurnover * 100) / 100,
          totalPlatformRevenueFees: Math.round(totalFees * 100) / 100,
          buyOrdersTotal: buys,
          sellOrdersTotal: sells,
          averageTradeSize: localState.trades.length ? Math.round((totalTurnover / localState.trades.length) * 100) / 100 : 0,
          auditedTrades: localState.trades.slice(0, 20)
        });
      }
    }

    // 10. /api/reports/export
    if (path === '/api/reports/export') {
      const type = params.get('type') || 'FINANCIAL_AUDIT';
      let csv = 'Trade ID,Timestamp,Trader Name,Symbol,Type,Order Type,Quantity,Price,Total,Fee,Status\n';
      localState.trades.forEach(t => {
        csv += `"${t.id}","${t.timestamp}","${t.userName}","${t.symbol}","${t.type}","${t.orderType}",${t.quantity},${t.price},${t.totalAmount},${t.fee},"${t.status}"\n`;
      });
      return makeResponse(csv, 200, 'text/csv');
    }

    // 11. /api/alerts
    if (path === '/api/alerts') {
      if (method === 'GET') {
        const uid = params.get('userId');
        const list = uid ? localState.alerts.filter(a => a.userId === uid) : localState.alerts;
        return makeResponse(list);
      }
      if (method === 'POST') {
        const id = 'alt_' + Date.now();
        const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
        const newAlert = {
          id,
          userId: body.userId,
          symbol: body.symbol,
          targetPrice: parseFloat(body.targetPrice),
          condition: body.condition || 'ABOVE',
          status: 'ACTIVE',
          createdAt: now,
          note: body.note || ''
        };
        localState.alerts.unshift(newAlert);
        saveState(localState);
        return makeResponse({ success: true, message: `Confirmation: Price alert created for ${newAlert.symbol} (${newAlert.condition} $${newAlert.targetPrice.toFixed(2)}).`, alert: newAlert }, 201);
      }
      if (method === 'DELETE') {
        const id = params.get('id');
        localState.alerts = localState.alerts.filter(a => a.id !== id);
        saveState(localState);
        return makeResponse({ success: true, message: 'Price alert removed successfully.' });
      }
    }

    // 12. /api/notifications
    if (path === '/api/notifications') {
      const uid = params.get('userId');
      const list = uid ? localState.notifications.filter(n => n.userId === uid || n.userId === 'usr_all') : localState.notifications;
      return makeResponse(list);
    }
    if (path === '/api/notifications/clear') {
      const uid = params.get('userId');
      localState.notifications = localState.notifications.filter(n => n.userId !== uid);
      saveState(localState);
      return makeResponse({ success: true, message: 'Notifications cleared.' });
    }

    // 13. /api/news
    if (path === '/api/news') {
      const cat = params.get('category');
      const list = (cat && cat !== 'ALL') ? localState.news.filter(n => n.category === cat) : localState.news;
      return makeResponse(list);
    }

    return makeResponse({ error: 'Endpoint not found' }, 404);
  }

  // Intercept window.fetch for /api calls
  const originalFetch = window.fetch;
  window.fetch = async function (resource, options = {}) {
    const urlStr = typeof resource === 'string' ? resource : (resource?.url || '');

    if (urlStr.startsWith('/api') || urlStr.includes('/api/')) {
      if (isStandaloneMode) {
        return handleLocalApi(urlStr, options);
      }
      try {
        const res = await originalFetch(resource, options);
        // If static host returns 404 for API route, seamlessly switch to standalone mode
        if (res.status === 404) {
          isStandaloneMode = true;
          return handleLocalApi(urlStr, options);
        }
        return res;
      } catch (err) {
        // Backend not reachable, switch to standalone mode
        isStandaloneMode = true;
        return handleLocalApi(urlStr, options);
      }
    }

    return originalFetch(resource, options);
  };

  window.__ApexTradeLocalEngine = {
    getState: () => localState,
    saveState: () => saveState(localState),
    resetState: () => {
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    }
  };
})();
